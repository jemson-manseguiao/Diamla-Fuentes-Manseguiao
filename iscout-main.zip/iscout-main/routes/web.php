<?php

use App\Http\Livewire\Auth\Login;
use Illuminate\Support\Facades\Route;
use App\Http\Livewire\Admin\Dashboard;
use App\Http\Livewire\Admin\Driver;
use App\Http\Livewire\Admin\DriverVehicle;
use App\Http\Livewire\Admin\Fuel;
use App\Http\Livewire\Admin\Settings;
use App\Http\Livewire\Admin\Vehicle;
use App\Http\Livewire\Admin\Time;
use App\Http\Livewire\Auth\Register;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::prefix('admin')->middleware('authCheck')->group(function () {
    Route::get('login', Login::class)->name('auth.login');
    Route::get('register', Register::class)->name('auth.register');


    Route::get('dashboard', Dashboard::class)->name('admin.dashboard');
    Route::get('driver', Driver::class)->name('admin.driver');
    Route::get('time', Time::class)->name('admin.time');
    Route::get('vehicle', Vehicle::class)->name('admin.vehicle');
    Route::get('fuel', Fuel::class)->name('admin.fuel');
    Route::get('vehicle/assign', DriverVehicle::class)->name('admin.drivervehicle');
    Route::get('settings', Settings::class)->name('admin.settings');
});