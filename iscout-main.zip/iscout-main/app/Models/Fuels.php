<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Fuels extends Model
{
    use HasFactory;

    public $timestamps = false;

    public $fillable = [
        'fuel_type',
        'fuel_expense',
        'fuel_name'
    ];
}
