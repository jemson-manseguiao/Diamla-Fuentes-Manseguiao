<?php

namespace App\Http\Livewire\Admin;

use App\Models\Fuels;
use App\Models\Drivers;
use Livewire\Component;
use App\Models\Vehicles;
use App\Models\DriverVehicles;

class Dashboard extends Component
{

    public $showModal = false;
    public $vehicleLocation;

    public function showMapModal($id) {
        $this->showModal = true;

        $data = Vehicles::where('vehicle_id', $id)->get();

        $this->dispatchBrowserEvent('showMapData', [
            'latitude' => $data[0]['latitude'],
            'longitude' => $data[0]['longitude'],
        ]);
    }

    public function render()
    {
        $recordss = DriverVehicles::join('drivers', 'drivers.driver_id', '=', 'driver_vehicles.driver_id')->join('vehicles', 'vehicles.vehicle_id', '=', 'driver_vehicles.vehicle_id')->select('name', 'plate_number', 'driver_vehicles.status', 'vehicles.vehicle_id')->get();

        return view('livewire.admin.dashboard', ['driverCount' => Drivers::all()->count(), 'vehicleCount' => Vehicles::all()->count(), 'fuelCount' => Fuels::all()->count(), 'records' => $recordss])->layout('layouts.admin.app');
    }
}
