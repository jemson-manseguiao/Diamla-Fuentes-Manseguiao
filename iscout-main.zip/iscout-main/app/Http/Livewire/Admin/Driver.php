<?php

namespace App\Http\Livewire\Admin;

use App\Models\Drivers;
use Livewire\Component;

class Driver extends Component
{

    public $name;
    public $status;
    public $phone;
    public $showModal = false;
    public $updateName;
    public $updateStatus;
    public $updatePhone;
    public $driver_id;

    protected $listeners = ['delete'];

    public function store() {
        $this->validate($this->rules());

        Drivers::create($this->modelData());

        session()->flash('message');

        return redirect()->route('admin.driver');
    }

    public function modelData() {
        return [
            'name' => $this->name,
            'status' => $this->status,
            'phone_number' => $this->phone
        ];
    }

    public function rules() {
        return [
            'name' => 'required',
            'status' => 'required',
            'phone' => 'required'
        ];
    }

    public function deleteModal($id) {
        $this->dispatchBrowserEvent('swal:deleteModal', [
            'type' => 'warning',
            'title' => 'Are you sure?',
            'text' => "You won't be able to revert this!",
            'id' => $id
        ]);
    }

    public function delete($id) {
        Drivers::where('driver_id', $id)->delete();

        session()->flash('delete');

        return redirect()->route('admin.driver');
    }

    public function update() {
        Drivers::where('driver_id', $this->driver_id)->update($this->modalDataUpdate());


        session()->flash('update');

        return redirect()->route('admin.driver');
    }

    public function showUpdateModal($id) {
        $this->driver_id = $id;
        $data = Drivers::where('driver_id', $id)->get();

        $this->updateName = $data[0]->name; 
        $this->updateStatus = $data[0]->status; 
        $this->updatePhone = $data[0]->phone_number; 

        $this->showModal = true;
    }

    public function modalDataUpdate() {
        return [
            'name' => $this->updateName,
            'status' => $this->updateStatus,
            'phone_number' => $this->updatePhone
        ];
    }

    public function render()
    {

        return view('livewire.admin.driver', ['drivers' => Drivers::all()])->layout('layouts.admin.app');
    }
}
