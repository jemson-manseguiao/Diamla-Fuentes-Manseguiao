<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;
use App\Models\Vehicles;

class Vehicle extends Component
{

    public $plate;
    public $color;
    public $status;
    public $type;

    public $vehicle_id;
    public $updatePlate;
    public $updateColor;
    public $updateStatus;
    public $updateType;

    public $showModal = false;
    public $locations = [
        [8.482044, 124.645599],
        [8.482166, 124.628691],
        [8.484713, 124.650106],
        [8.503060, 124.642778],
        [8.508196, 124.652166]
    ];

    protected $listeners = ['delete'];


    public function store() {
        $this->validate($this->rules());

        Vehicles::create($this->modelData());

        session()->flash('message');

        return redirect()->route('admin.vehicle');
    }

    public function modelData() {
        
        $rand = rand(0,4);

        return [
            'plate_number' => $this->plate,
            'fuel_type' => $this->type,
            'vehicle_color' => $this->color,
            'status' => $this->status,
            'latitude' => $this->locations[$rand][0],
            'longitude' => $this->locations[$rand][1],
        ];
    }

    public function rules() {
        return [
            'plate' => 'required',
            'type' => 'required',
            'color' => 'required',
            'status' => 'required'
        ];
    }

    public function deleteModal($id) {
        $this->dispatchBrowserEvent('swal:deleteModal', [
            'type' => 'warning',
            'title' => 'Are you sure?',
            'text' => "You won't be able to revert this!",
            'id' => $id
        ]);
    }

    public function delete($id) {
        Vehicles::where('vehicle_id', $id)->delete();

        session()->flash('delete');

        return redirect()->route('admin.vehicle');
    }

    public function update() {
        Vehicles::where('vehicle_id', $this->vehicle_id)->update($this->modalDataUpdate());


        session()->flash('update');

        return redirect()->route('admin.vehicle');
    }

    public function showUpdateModal($id) {
        $this->vehicle_id = $id;
        $data = Vehicles::where('vehicle_id', $id)->get();

        $this->updatePlate = $data[0]->plate_number; 
        $this->updateStatus = $data[0]->status; 
        $this->updateColor = $data[0]->vehicle_color; 
        $this->updateType = $data[0]->fuel_type; 

        $this->showModal = true;
    }

    public function modalDataUpdate() {

        return [
            'plate_number' => $this->updatePlate,
            'vehicle_color' => $this->updateColor,
            'status' => $this->updateStatus,
            
        ];
    }


    public function render()
    {

        

        return view('livewire.admin.vehicle', ['vehicle' => Vehicles::all()])->layout('layouts.admin.app');
    }
}
