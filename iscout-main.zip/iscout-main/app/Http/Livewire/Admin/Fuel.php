<?php

namespace App\Http\Livewire\Admin;

use App\Models\Fuels;
use Livewire\Component;

class Fuel extends Component
{

    public $type;
    public $expense;
    public $name;

    public $showModal = false;

    public $updateType;
    public $updateExpense;
    public $updateName;
    public $fuel_id;

    protected $listeners = ['delete'];

    public function store() {
        $this->validate($this->rules());

        Fuels::create($this->modelData());

        session()->flash('message');

        return redirect()->route('admin.fuel');
    }

    public function modelData() {
        return [
            'fuel_type' => $this->type,
            'fuel_expense' => $this->expense,
            'fuel_name' => $this->name
        ];
    }

    public function rules() {
        return [
            'type' => 'required',
            'expense' => 'required',
            'name' => 'required'
        ];
    }

    public function deleteModal($id) {
        $this->dispatchBrowserEvent('swal:deleteModal', [
            'type' => 'warning',
            'title' => 'Are you sure?',
            'text' => "You won't be able to revert this!",
            'id' => $id
        ]);
    }

    public function delete($id) {
        Fuels::where('fuel_id', $id)->delete();

        session()->flash('delete');

        return redirect()->route('admin.fuel');
    }

    public function update() {
        Fuels::where('fuel_id', $this->fuel_id)->update($this->modalDataUpdate());


        session()->flash('update');

        return redirect()->route('admin.vehicle');
    }

    public function showUpdateModal($id) {
        $this->fuel_id = $id;
        $data = Fuels::where('fuel_id', $id)->get();

        $this->updateType = $data[0]->fuel_type; 
        $this->updateExpense = $data[0]->fuel_expense; 
        $this->updateName = $data[0]->fuel_name; 

        $this->showModal = true;
    }

    public function modalDataUpdate() {
        return [
            'fuel_type' => $this->updateType,
            'fuel_expense' => $this->updateExpense,
            'fuel_name' => $this->updateName,
        ];
    }

    public function render()
    {
        return view('livewire.admin.fuel', ['fuel' => Fuels::all()])->layout('layouts.admin.app');
    }
}
