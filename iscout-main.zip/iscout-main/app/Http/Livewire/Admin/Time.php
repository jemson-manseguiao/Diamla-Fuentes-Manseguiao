<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class Time extends Component
{

    public $driver_id;
    public $time_in;
    public $time_out;

    public function render()
    {
        

        return view('livewire.admin.time')->layout('layouts.admin.app');
    }
}
