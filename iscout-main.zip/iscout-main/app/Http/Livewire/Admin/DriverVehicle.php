<?php

namespace App\Http\Livewire\Admin;

use App\Models\Drivers;
use Livewire\Component;
use App\Models\Vehicles;
use App\Models\DriverVehicles;

class DriverVehicle extends Component
{

    public $driver_id;
    public $vehicle_id;
    public $status;

    
    protected $listeners = ['delete'];

    public function store() {
        $this->validate($this->rules());

        DriverVehicles::create($this->modelData());

        session()->flash('message');

        return redirect()->route('admin.drivervehicle');
    }

    public function modelData() {
        return [
            'driver_id' => $this->driver_id,
            'vehicle_id' => $this->vehicle_id,
            'status' => $this->status
        ];
    }

    public function rules() {
        return [
            'driver_id' => 'required',
            'vehicle_id' => 'required',
            'status' => 'required'
        ];
    }

    public function deleteModal($id) {
        $this->dispatchBrowserEvent('swal:deleteModal', [
            'type' => 'warning',
            'title' => 'Are you sure?',
            'text' => "You won't be able to revert this!",
            'id' => $id
        ]);
    }

    public function delete($id) {
        DriverVehicles::where('id', $id)->delete();

        session()->flash('delete');

        return redirect()->route('admin.drivervehicle');
    }


    public function render()
    {

        $recordss = DriverVehicles::join('drivers', 'drivers.driver_id', '=', 'driver_vehicles.driver_id')->join('vehicles', 'vehicles.vehicle_id', '=', 'driver_vehicles.vehicle_id')->select('driver_vehicles.id','name', 'plate_number', 'driver_vehicles.status')->get();

        // dd($recordss);

        return view('livewire.admin.driver-vehicle',['drivers' => Drivers::select('driver_id', 'name')->get(), 'vehicles' => Vehicles::select('vehicle_id', 'plate_number')->get(), 'records' => $recordss])->layout('layouts.admin.app');
    }
}
