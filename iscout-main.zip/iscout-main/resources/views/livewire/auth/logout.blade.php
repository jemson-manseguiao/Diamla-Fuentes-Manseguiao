<button wire:click="logout" class="flex items-center text-sm py-4 px-6 h-12 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-blue-600 hover:bg-blue-50 transition duration-300 ease-in-out w-full" data-mdb-ripple="true" data-mdb-ripple-color="primary">
    <i data-lucide="log-out" class="w-4 h-4"></i>
    <span class="pl-4">Logout</span>
</button>