<section class="w-full">
    <div class="flex flex-col justify-center min-h-screen py-12 sm:px-6 lg:px-8">
        <div class="sm:mx-auto sm:w-full sm:max-w-md">
            <div class="flex justify-center">
                <svg viewBox="0 0 369.79633096218646 100.49867660678368" height="100.49867660678368" width="369.79633096218646" style="width: 369.796px; height: 100.499px;"><defs id="SvgjsDefs1364"></defs><g id="SvgjsG1365" featurekey="QMusi1-0" transform="matrix(0.8620366903781356,0,0,0.8620366903781356,0,15.68981654810932)" fill="#222831"><g xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M93.151,39.049l-5.223-26.086C87.31,9.982,83.824,5,76.746,5H50.305H23.863   c-7.075,0-10.675,4.982-11.173,7.963L7.153,39.352C3.803,39.971,0,43.02,0,46.619v22.098c0,3.227,4,5.961,4,6.949v16.139   c3,2.113,5.334,3.602,8.314,3.602c2.855,0,5.686-1.615,8.686-3.602V76.287L33.67,77h16.635h16.635L80,76.287v15.518   c3,1.986,5.893,3.602,8.75,3.602c2.855,0,5.25-1.488,8.25-3.602V75.666c0-0.988,3-3.723,3-6.949V46.619   C100,43.02,96.381,39.668,93.151,39.049z M79.231,34.955l-28.927-1.246l-28.923,1.246c-5.217,0.244-7.823-1.367-7.075-6.211   l1.488-7.562C17.532,12.738,26.349,12,35.286,12h15.019h14.897c9.062,0,17.875,0.738,19.612,9.182l1.367,7.752   C86.926,33.777,84.319,35.199,79.231,34.955z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M26.221,21.297c0,2.107,1.118,4.094,2.609,5.211c0,0.125,0.125,0.5-0.124,0.621   c-0.993,1.246-7.57,2.734-7.947,4.592c-0.121,0.5-0.37,1.244-0.246,1.244c0.374,0,11.793-0.496,12.167-0.496   c0.37,0,9.806-0.373,10.176-0.373c0.128-0.125,0.128-0.246-0.121-0.869c-0.868-1.861-6.209-3.102-7.448-3.971   c-0.249-0.248-0.249-0.623-0.125-0.748c1.492-1.117,2.36-3.104,2.36-5.211c0-3.602-2.484-6.457-5.59-6.457   C28.706,14.84,26.221,17.695,26.221,21.297"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M74.14,21.297c0,2.107-1.118,4.094-2.606,5.211c0,0.125-0.125,0.5,0,0.748   c1.118,1.119,7.698,2.607,8.068,4.465c0.125,0.5,0.249,1.244,0.125,1.244c-0.246,0-11.793-0.496-12.039-0.496   c-0.377,0-9.81-0.373-10.184-0.373c-0.121-0.125-0.121-0.246,0-0.869c0.869-1.861,6.331-3.102,7.574-3.971   c0.249-0.248,0.249-0.623,0.124-0.748c-1.488-1.117-2.485-2.977-2.485-5.211c0-3.602,2.61-6.457,5.712-6.457   C71.658,14.84,74.14,17.695,74.14,21.297"></path></g></g><g id="SvgjsG1366" featurekey="UyNsn2-0" transform="matrix(4.789330799972893,0,0,4.789330799972893,107.6283714899865,3.658676032687314)" fill="#222831"><path d="M4.3 9.56 l0 10.44 l-3.02 0 l0 -7.22 l0.1 -0.72 l-1.72 0 l1.36 -2.5 l3.28 0 z M4.22 8.7 l-3 0 l0 -2.72 l3 0 l0 2.72 z M9.34 13.620000000000001 c-0.42666 -0.17334 -0.82332 -0.36666 -1.19 -0.58 s-0.68332 -0.47 -0.94998 -0.77 s-0.47332 -0.65334 -0.61998 -1.06 s-0.22 -0.89 -0.22 -1.45 c0 -0.69334 0.12 -1.3033 0.36 -1.83 s0.57666 -0.97 1.01 -1.33 s0.95668 -0.63334 1.57 -0.82 s1.2933 -0.28 2.04 -0.28 c0.61334 0 1.24 0.06334 1.88 0.19 s1.4067 0.34332 2.3 0.64998 l-1.36 2.44 c-0.86666 -0.41334 -1.78 -0.62 -2.74 -0.62 c-0.18666 0 -0.38 0.02 -0.58 0.06 s-0.38 0.11 -0.54 0.21 s-0.29334 0.23666 -0.4 0.41 s-0.16 0.4 -0.16 0.68 c0 0.22666 0.04334 0.41332 0.13 0.55998 s0.19666 0.27332 0.33 0.37998 s0.28668 0.19666 0.46002 0.27 s0.34668 0.14334 0.52002 0.21 l1.18 0.46 c0.50666 0.2 0.97 0.41 1.39 0.63 s0.77666 0.48666 1.07 0.8 s0.52 0.69668 0.68 1.15 s0.24 1.02 0.24 1.7 s-0.12334 1.3 -0.37 1.86 s-0.60666 1.0367 -1.08 1.43 s-1.0567 0.7 -1.75 0.92 s-1.4867 0.33 -2.38 0.33 c-0.41334 0 -0.79334 -0.01334 -1.14 -0.04 s-0.68332 -0.07332 -1.01 -0.13998 s-0.65332 -0.14666 -0.97998 -0.24 s-0.67666 -0.21334 -1.05 -0.36 l0.68 -2.8 c0.54666 0.14666 1.0833 0.27666 1.61 0.39 s1.0633 0.17 1.61 0.17 c0.73334 0 1.2933 -0.09666 1.68 -0.29 s0.61332 -0.56334 0.67998 -1.11 c0.02666 -0.28 -0.0066796 -0.51334 -0.10002 -0.7 s-0.22668 -0.34332 -0.40002 -0.46998 s-0.36668 -0.23 -0.58002 -0.31 l-0.64 -0.24 z M25.46 18.88 c-0.53334 0.42666 -1.1067 0.74334 -1.72 0.95 s-1.24 0.31 -1.88 0.31 c-0.69334 0 -1.3467 -0.09334 -1.96 -0.28 s-1.15 -0.49 -1.61 -0.91 s-0.82334 -0.96666 -1.09 -1.64 s-0.4 -1.49 -0.4 -2.45 c0 -0.94666 0.13334 -1.7567 0.4 -2.43 s0.63 -1.2267 1.09 -1.66 s0.99666 -0.75334 1.61 -0.96 s1.2667 -0.31 1.96 -0.31 c0.42666 0 0.89332 0.06 1.4 0.18 s1.0133 0.3 1.52 0.54 l-1.32 2.16 c-0.22666 -0.10666 -0.49332 -0.18332 -0.79998 -0.22998 s-0.57332 -0.07 -0.79998 -0.07 c-0.61334 0 -1.1233 0.21666 -1.53 0.65 s-0.61 1.1433 -0.61 2.13 c0 0.50666 0.05334 0.92 0.16 1.24 s0.25666 0.58 0.45 0.78 s0.42 0.34666 0.68 0.44 s0.54334 0.15334 0.85 0.18 c0.41334 0.04 0.82334 0.0066602 1.23 -0.1 s0.77 -0.28 1.09 -0.52 z M30.82 9.44 c0.69334 0 1.34 0.09668 1.94 0.29002 s1.1167 0.50334 1.55 0.93 s0.77334 0.98 1.02 1.66 s0.37 1.5 0.37 2.46 s-0.12334 1.78 -0.37 2.46 s-0.58666 1.2333 -1.02 1.66 s-0.95 0.73666 -1.55 0.93 s-1.2467 0.29 -1.94 0.29 c-0.70666 0 -1.3567 -0.09666 -1.95 -0.29 s-1.1067 -0.50334 -1.54 -0.93 s-0.77334 -0.98 -1.02 -1.66 s-0.37 -1.5 -0.37 -2.46 c0 -0.94666 0.12334 -1.7567 0.37 -2.43 s0.58666 -1.2267 1.02 -1.66 s0.94668 -0.75 1.54 -0.95 s1.2433 -0.3 1.95 -0.3 z M30.82 17.5 c0.6 0 1.07 -0.2 1.41 -0.6 s0.51 -1.1067 0.51 -2.12 s-0.17 -1.7233 -0.51 -2.13 s-0.81 -0.61 -1.41 -0.61 c-0.58666 0 -1.0567 0.21 -1.41 0.63 s-0.53 1.1233 -0.53 2.11 c0 1.0133 0.17334 1.72 0.52 2.12 s0.82 0.6 1.42 0.6 z M37.5 9.56 l3.04 -0.000039062 l0 5.44 c0 0.46666 0.04 0.85666 0.12 1.17 s0.2 0.56 0.36 0.74 s0.35666 0.30666 0.59 0.38 s0.51 0.11 0.83 0.11 c0.38666 0 0.73332 -0.02 1.04 -0.06 l-0.04 -0.36 l0 -7.42 l3.04 0 l0 9.88 c-0.49334 0.17334 -1.0833 0.32668 -1.77 0.46002 s-1.39 0.2 -2.11 0.2 c-0.68 0 -1.33 -0.05334 -1.95 -0.16 s-1.1633 -0.33332 -1.63 -0.67998 s-0.83666 -0.85 -1.11 -1.51 s-0.41 -1.55 -0.41 -2.67 l0 -5.52 z M49.04 12.059999999999999 l-1.24 0 l0 -2.52 l1.24 0 l0 -2.84 l3 0 l0 2.84 l2.48 0 l-1.4 2.52 l-1.18 0 l0.1 0.64 l0 3.14 c0 0.34666 0.02334 0.62666 0.07 0.84 s0.12 0.38 0.22 0.5 s0.22666 0.20334 0.38 0.25 s0.33 0.07 0.53 0.07 c0.14666 0 0.32666 -0.01666 0.54 -0.05 s0.44 -0.07 0.68 -0.11 l0.16 1.34 l0.12 1.2 c-0.38666 0.08 -0.74 0.14 -1.06 0.18 s-0.64666 0.06 -0.98 0.06 c-1.24 0 -2.16 -0.28666 -2.76 -0.86 s-0.9 -1.52 -0.9 -2.84 l0 -4.36 z"></path></g></svg>
            </div>
        </div>
        <div class="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
            <h2 class="mt-6 text-3xl font-extrabold text-center text-neutral-600 font-nunito">Welcome back Admin!</h2>
        <div class="px-4 py-8 sm:px-10">
            @if (session('error'))
                <div class="bg-red-100 rounded-lg py-5 px-6 mb-3 text-base text-red-700 inline-flex items-center w-full" role="alert">
                    <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="times-circle" class="w-4 h-4 mr-2 fill-current" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm121.6 313.1c4.7 4.7 4.7 12.3 0 17L338 377.6c-4.7 4.7-12.3 4.7-17 0L256 312l-65.1 65.6c-4.7 4.7-12.3 4.7-17 0L134.4 338c-4.7-4.7-4.7-12.3 0-17l65.6-65-65.6-65.1c-4.7-4.7-4.7-12.3 0-17l39.6-39.6c4.7-4.7 12.3-4.7 17 0l65 65.7 65.1-65.6c4.7-4.7 12.3-4.7 17 0l39.6 39.6c4.7 4.7 4.7 12.3 0 17L312 256l65.6 65.1z"></path>
                    </svg>
                    {{ session('error') }}
                </div>
            @endif
            <form wire:submit.prevent="login">
            <div>
                <div class="flex -mx-3">
                    <div class="w-full px-3 mb-5">
                        <label for="password" class="block text-sm font-medium text-gray-700 mb-2"> Email </label>
                        <div class="flex">
                            <div class="w-10 z-10 pl-1 text-center pointer-events-none flex items-center justify-center"><i class="mdi mdi-email-outline text-gray-400 text-lg"></i></div>
                            <input type="email" class="w-full -ml-10 pl-10 pr-3 py-3 text-base text-neutral-600 placeholder-gray-300 transition duration-500 ease-in-out transform border border-transparent rounded-lg bg-gray-50 focus:outline-none focus:border-transparent focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-300
                            @error('email')
                                border-2 border-red-400
                            @enderror" placeholder="johndoe@example.com" wire:model.defer="email">
                        </div>
                        @error('email')
                            <span class="block text-red-500 text-sm mt-2">* {{ $message }}</span>
                        @enderror
                    </div>
                </div>
            </div>
    
            <div>
                <div class="flex -mx-3">
                    <div class="w-full px-3 mb-5">
                        <label for="password" class="block text-sm font-medium text-gray-700 mb-2"> Password </label>
                        <div class="flex">
                            <div class="w-10 z-10 pl-1 text-center pointer-events-none flex items-center justify-center"><i class="mdi mdi-lock-outline text-gray-400 text-lg"></i></div>
                            <input type="password" class="w-full -ml-10 pl-10 pr-3 py-3 text-base text-neutral-600 placeholder-gray-300 transition duration-500 ease-in-out transform border border-transparent rounded-lg bg-gray-50 focus:outline-none focus:border-transparent focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-300
                            @error('password')
                                border-2 border-red-400
                            @enderror" placeholder="**********" wire:model.defer="password">
                        </div>
                        @error('password')
                            <span class="block text-red-500 text-sm mt-2">* {{ $message }}</span>
                        @enderror
                    </div>
                </div>
            </div>
    
            <div class="flex items-center justify-between mb-5">
                <div class="flex items-center">
                <input id="remember-me" name="remember-me" type="checkbox" class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                <label for="remember-me" class="block ml-2 text-sm text-neutral-600"> Remember me </label>
                </div>
    
                <div class="text-sm">
                <a href="#" class="font-medium text-blue-600 hover:text-blue-500"> Forgot your password? </a>
                </div>
            </div>
    
            <div>
                <button type="submit" class="flex items-center justify-center w-full px-10 py-4 text-base font-medium text-center text-white transition duration-500 ease-in-out transform bg-blue-600 rounded-xl hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">Sign in</button>
            </div>
            </form>
            {{-- <div class="flex justify-center items-center mt-6">
                <a href="{{ route('admin.register') }}"  class="inline-flex items-center font-bold text-blue-500 hover:text-blue-700 text-xs text-center">
                    <span>
                    <svg class="h-6 w-6" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor">
                        <path d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                    </svg>
                    </span>
                    <span class="ml-2">You don't have an account?</span>
                </a>
            </div> --}}
        </div>
        </div>
    </div>
</section>

