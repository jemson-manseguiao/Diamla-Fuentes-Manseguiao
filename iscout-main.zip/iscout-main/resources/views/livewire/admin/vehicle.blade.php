<div class="relative shadow-md sm:rounded-lg p-4" x-data="{open: @entangle('showModal')}">
    <div class="flex justify-between items-center">
        <div class="flex gap-2">
            <i data-lucide="align-justify" class="text-gray-600"></i>
            <p>Vehicles Information</p>
        </div>
        <div>
            <button class="relative inline-flex items-center px-8 py-3 overflow-hidden text-white bg-blue-600 rounded group active:bg-blue-500 focus:outline-none focus:ring" data-modal-toggle="authentication-modal">
                <span class="absolute left-0 transition-transform -translate-x-full group-hover:translate-x-4">
                    <i class="mdi mdi-car"></i>
                </span>
                
                <span class="text-sm font-medium transition-all group-hover:ml-4">
                    Add Vehicle
                </span>
            </button>
        </div>
    </div>

    <br>
    <hr>
    <br>

    <div class="relative overflow-x-auto shadow-md sm:rounded-lg" wire:ignore>
        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">
                        Vehicle Plate #
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Vehicle Color
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Fuel Type
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Status
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                @foreach ($vehicle as $item)
                <tr class="border-b dark:bg-gray-800 dark:border-gray-700 odd:bg-white even:bg-gray-50 odd:dark:bg-gray-800 even:dark:bg-gray-700">
                    <th scope="row" class="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                        {{ $item->plate_number }}
                    </th>
                    <td class="px-6 py-4">
                        {{ $item->vehicle_color }}
                    </td>
                    <td class="px-6 py-4">
                        {{ $item->fuel_type }}
                    </td>
                    <td class="px-6 py-4">
                        <span class="bg-red-200 text-red-600 py-1 px-3 rounded-full text-xs">{{ $item->status }}</span>
                    </td>
                    <td class="px-6 py-4 flex gap-4">
                        <button><i data-lucide="edit" class="text-green-400 w-4 h-4" wire:click="showUpdateModal({{ $item->vehicle_id }})"></i></button>
                        <button><i data-lucide="trash" class="text-red-400 w-4 h-4" wire:click="deleteModal({{ $item->vehicle_id }})"></i></button>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div id="authentication-modal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 w-full md:inset-0 h-modal md:h-full bg-white bg-opacity-75">
        <div class="relative p-4 w-full max-w-md h-full md:h-auto">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <button type="button" class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-800 dark:hover:text-white" data-modal-toggle="authentication-modal">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>  
                </button>
                <div class="py-6 px-6 lg:px-8">
                    <h3 class="mb-4 text-xl font-medium text-gray-900 dark:text-white">Fill up vehicle information</h3>
                    <form class="space-y-6" wire:submit.prevent="store">
                        <div>
                            <label for="text" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Vehicle Plate #</label>
                            <input type="text" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="XXX-XXX" required wire:model.defer="plate">
                        </div>
                        <div>
                            <label for="text" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Fuel Type</label>
                            <select name="" id="" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" wire:model.defer="type">
                                <option value="">-- SELECT FUEL TYPE --</option>
                                <option value="Gasoline">Gasoline</option>
                                <option value="Diesel">Diesel</option>
                                <option value="Bio-diesel">Bio-diesel</option>
                                <option value="Ethanol">Ethanol</option>
                            </select>
                        </div>
                        <div>
                            <label for="text" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Vehicle Color</label>
                            <input type="text" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="Blue/Orange" required wire:model.defer="color">
                        </div>
                        <div>
                            <label for="text" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Status</label>
                            <input type="text" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="Good/Crashed" required wire:model.defer="status">
                        </div>
                        <button type="submit" class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Save Vehicle</button>
                    </form>
                </div>
            </div>
        </div>
    </div> 

    <div x-show="open" class="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen px-4 text-center md:items-center sm:block sm:p-0">
            <div x-cloak @click="open = false" x-show="open" 
                x-transition:enter="transition ease-out duration-300 transform"
                x-transition:enter-start="opacity-0" 
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition ease-in duration-200 transform"
                x-transition:leave-start="opacity-100" 
                x-transition:leave-end="opacity-0"
                class="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-40" aria-hidden="true"
            ></div>

            <div x-cloak x-show="open" 
                x-transition:enter="transition ease-out duration-300 transform"
                x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95" 
                x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
                x-transition:leave="transition ease-in duration-200 transform"
                x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100" 
                x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                class="relative bg-white rounded-lg shadow dark:bg-gray-700 w-96 p-8 mx-auto mt-20"
            >
            <div >
                <h3 class="mb-4 text-xl font-medium text-gray-900 dark:text-white text-left">Update vehicle information</h3>
                <form class="space-y-6" wire:submit.prevent="update">
                    <div>
                        <label for="text" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 text-left">Vehicle Plate #</label>
                        <input type="text" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="XXX-XXX" required wire:model.defer="updatePlate" value="{{ $updatePlate }}">
                        @error('name')
                            <span class="block text-red-500 text-sm mt-2">* {{ $message }}</span>
                        @enderror
                    </div>
                    <div>
                        <label for="text" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 text-left">Vehicle Color</label>
                        <input type="text" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="Blue/Orange" required wire:model.defer="updateColor" value="{{ $updateColor }}">
                        @error('status')
                            <span class="block text-red-500 text-sm mt-2">* {{ $message }}</span>
                        @enderror
                    </div>
                    <div>
                        <label for="text" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 text-left">Vehicle Fuel Type</label>
                        <input type="text" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="Blue/Orange" disabled wire:model.defer="updateType" value="{{ $updateColor }}">
                        @error('phone')
                            <span class="block text-red-500 text-sm mt-2">* {{ $message }}</span>
                        @enderror
                    </div>
                    <div>
                        <label for="text" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 text-left">Status</label>
                        <input type="text" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="Good/Bad" required wire:model.defer="updateStatus" value="{{ $updateStatus }}">
                        @error('status')
                            <span class="block text-red-500 text-sm mt-2">* {{ $message }}</span>
                        @enderror
                    </div>
                    <button type="submit" class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Update Vehicle</button>
                </form>
            </div>
            </div>
        </div>
    </div>
</div>

<script>

window.addEventListener('swal:deleteModal', event => {
    Swal.fire({
        title: event.detail.title,
        text: event.detail.text,
        icon: event.detail.type,
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((willDelete) => {
        if (willDelete.isConfirmed) {
            window.livewire.emit('delete', event.detail.id)
        }
    })
})

@if (Session::has('message'))
    Swal.fire({
    icon: 'success',
    title: 'Success',
    text: 'Vehicle added successfully!',
    showConfirmButton: true,
    })
@endif
@if (Session::has('update'))
    Swal.fire({
    icon: 'success',
    title: 'Success',
    text: 'Vehicle updated successfully!',
    showConfirmButton: true,
    })
@endif
@if (Session::has('delete'))
    Swal.fire({
    icon: 'success',
    title: 'Deleted!',
    text: 'Vehicle has been deleted!',
    showConfirmButton: true,
    })
@endif
</script>