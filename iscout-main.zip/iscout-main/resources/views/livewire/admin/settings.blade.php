<div class="bg-white shadow-md rounded p-4"> 
    <div>
        <h2 class=" text-xl pb-4 text-black">Profile</h2>
    </div>
    <hr>
    <div class="flex flex-col p-4">
        <div class="flex gap-2 my-10">
            <div class="w-2/5">
                <h2 class="text-md">Profile Information</h2>
                <p class="text-sm">Update your account's profile information and email address.</p>
            </div>
            <div class="bg-white shadow-lg w-3/5 p-4 flex flex-col rounded-md">
                <div class="flex flex-col p-2">
                    <label for="" class="text-sm">Name</label>
                    <input type="text" class="block w-full px-5 py-3 text-base text-neutral-600 placeholder-gray-300 transition duration-500 ease-in-out transform border border-transparent rounded-lg bg-gray-100 focus:outline-none focus:border-transparent focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-300" wire:model.defer="name">
                </div>
                <div class="flex flex-col p-2">
                    <label for="" class="text-sm">Email</label>
                    <input type="text" class="block w-full px-5 py-3 text-base text-neutral-600 placeholder-gray-300 transition duration-500 ease-in-out transform border border-transparent rounded-lg bg-gray-100 focus:outline-none focus:border-transparent focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-300" wire:model.defer="email">
                </div>
                <div class="flex justify-end mr-2">
                    <button class="inline-flex items-center px-8 py-3 text-white bg-blue-600 border border-blue-600 rounded hover:bg-transparent hover:text-blue-600 active:text-blue-500 focus:outline-none focus:ring" wire:click="saveProfile"><span class="text-sm font-medium">
                        Save &nbsp;</span>
                    
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-device-floppy" width="20" height="20" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                            <path d="M6 4h10l4 4v10a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2" />
                            <circle cx="12" cy="14" r="2" />
                            <polyline points="14 4 14 8 8 8 8 4" />
                        </svg></button>
                </div>
            </div>
        </div>
        <hr>
        <div class="flex gap-2 my-10">
            <div class="w-2/5">
                <h2 class="text-md">Update Password</h2>
                <p class="text-sm">Ensure your account is using a long, random password to stay secure.</p>
            </div>
            <div class="bg-white shadow-md border-1 w-3/5 p-4 flex flex-col rounded-md">
                <div class="flex flex-col p-2">
                    <label for="" class="text-sm">Current Password</label>
                    <input type="password" class="block w-full px-5 py-3 text-base text-neutral-600 placeholder-gray-300 transition duration-500 ease-in-out transform border border-transparent rounded-lg bg-gray-100 focus:outline-none focus:border-transparent focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-300" wire:model.defer="currentPassword">
                    @error('currentPassword')
                        <span class="text-red-500 text-sm">* {{ $message }}</span>
                    @enderror
                    @if ($currentPass)
                        <span class="text-red-500 text-sm">* Current password does not match.</span>
                    @else
                        <span></span>
                    @endif
                </div>
                <div class="flex flex-col p-2">
                    <label for="" class="text-sm">New Password</label>
                    <input type="password" class="block w-full px-5 py-3 text-base text-neutral-600 placeholder-gray-300 transition duration-500 ease-in-out transform border border-transparent rounded-lg bg-gray-100 focus:outline-none focus:border-transparent focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-300" wire:model.defer="newPassword">
                    @error('newPassword')
                        <span class="text-red-500 text-sm">* {{ $message }}</span>
                    @enderror
                </div>
                <div class="flex flex-col p-2">
                    <label for="" class="text-sm">Confirm Password</label>
                    <input type="password" class="block w-full px-5 py-3 text-base text-neutral-600 placeholder-gray-300 transition duration-500 ease-in-out transform border border-transparent rounded-lg bg-gray-100 focus:outline-none focus:border-transparent focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-300" wire:model.defer="confirmPassword">
                    @error('confirmPassword')
                        <span class="text-red-500 text-sm">* {{ $message }}</span>
                    @enderror
                </div>
                <div class="flex justify-end mr-2">
                    <button class="inline-flex items-center px-8 py-3 text-white bg-blue-600 border border-blue-600 rounded hover:bg-transparent hover:text-blue-600 active:text-blue-500 focus:outline-none focus:ring" wire:click="savePassword"><span class="text-sm font-medium">
                        Save &nbsp;</span>
                    
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-device-floppy" width="20" height="20" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                            <path d="M6 4h10l4 4v10a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2" />
                            <circle cx="12" cy="14" r="2" />
                            <polyline points="14 4 14 8 8 8 8 4" />
                        </svg></button>
                </div>
            </div>
        </div>
        <hr>
    </div>
</div>
