<div x-data="{open: @entangle('showModal')}" wire:ignore.self>
    <div class="flex justify-evenly gap-12 ">
        <div class="w-full">
            <div class="bg-blue-500 dark:bg-gray-800 shadow-lg rounded-md flex items-center justify-between p-3 border-b-4 border-blue-600 dark:border-gray-600 text-white font-medium group">
                <div class="flex justify-center items-center w-14 h-14 bg-white rounded-full transition-all duration-300 transform group-hover:rotate-12">
                <i data-lucide="user" class="w-10 h-10 text-blue-400"></i>
            </div>
            <div class="text-right">
                <p class="text-2xl">{{ $driverCount }}</p>
                <p>Drivers</p>
            </div>
            </div>
        </div>
        <div class="w-full">
            <div class="bg-blue-500 dark:bg-gray-800 shadow-lg rounded-md flex items-center justify-between p-3 border-b-4 border-blue-600 dark:border-gray-600 text-white font-medium group">
                <div class="flex justify-center items-center w-14 h-14 bg-white rounded-full transition-all duration-300 transform group-hover:rotate-12">
                    <i data-lucide="car" class="w-10 h-10 text-blue-400"></i>
            </div>
            <div class="text-right">
                <p class="text-2xl">{{ $vehicleCount }}</p>
                <p>Vehicle</p>
            </div>
            </div>
        </div>
        <div class="w-full">
            <div class="bg-blue-500 dark:bg-gray-800 shadow-lg rounded-md flex items-center justify-between p-3 border-b-4 border-blue-600 dark:border-gray-600 text-white font-medium group">
                <div class="flex justify-center items-center w-14 h-14 bg-white rounded-full transition-all duration-300 transform group-hover:rotate-12">
                    <i data-lucide="fuel" class="w-10 h-10 text-blue-400"></i>
            </div>
            <div class="text-right">
                <p class="text-2xl">{{ $fuelCount }}</p>
                <p>Fuel</p>
            </div>
            </div>
        </div>
    </div>
    <div class="mt-12 flex justify-between gap-10">
        <div class=" w-2/3 relative overflow-x-auto shadow-md sm:rounded-lg">
            <h3 class="font-bold p-4">Vehicle's Driver</h3>
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            Driver Name
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Vehicle Plate #
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Status
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Action
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($records as $item)
                    <tr class="border-b dark:bg-gray-800 dark:border-gray-700 odd:bg-white even:bg-gray-50 odd:dark:bg-gray-800 even:dark:bg-gray-700">
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                            {{ $item->name }}
                        </th>
                        <td class="px-6 py-4">
                            {{ $item->plate_number }}
                        </td>
                        <td class="px-6 py-4">
                            {{ $item->status }}
                        </td>
                        <td class="px-6 py-4 flex gap-4">
                            <button wire:click="showMapModal({{ $item->vehicle_id }})"><i data-lucide="locate-fixed" class="text-blue-400 w-4 h-4"></i></button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <div x-show="open" class="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-center justify-center w-full h-screen px-4 text-center md:items-center sm:block sm:p-0 border-2 border-black">
            <div x-cloak @click="open = false" x-show="open" 
                x-transition:enter="transition ease-out duration-300 transform"
                x-transition:enter-start="opacity-0" 
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition ease-in duration-200 transform"
                x-transition:leave-start="opacity-100" 
                x-transition:leave-end="opacity-0"
                class="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-40" aria-hidden="true"
            ></div>

            <div x-cloak x-show="open" 
                x-transition:enter="transition ease-out duration-300 transform"
                x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95" 
                x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
                x-transition:leave="transition ease-in duration-200 transform"
                x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100" 
                x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                class="relative bg-white rounded-lg shadow dark:bg-gray-700 w-2/5 h-2/5 p-4 mx-auto mt-20"
            >
            <div  class="w-full h-4/5 p-4  rounded-2xl">
                <h3 class="mb-4 text-xl font-medium text-gray-900 dark:text-white text-left">Vehicles Location</h3>
                <div id="map" class="w-full h-full rounded-2xl" wire:ignore></div>
            </div>
            </div>
        </div>
    </div>
</div>

<script>
window.addEventListener('showMapData', event => {
    var center = [8.5084226, 124.6421088];
    // Create the map
    var map = L.map('map').setView(center, 10);
    

    L.tileLayer(
        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Data © <a href="http://osm.org/copyright">OpenStreetMap</a>',
            maxZoom: 18,
        }).addTo(map);

    var highIcon = new L.Icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41]
    });

    L.marker([event.detail.latitude, event.detail.longitude ], {draggable: false, icon: highIcon}).addTo(map);
})


</script>