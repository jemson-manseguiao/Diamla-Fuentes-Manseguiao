<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <script defer src="https://unpkg.com/alpinejs@3.10.2/dist/cdn.min.js"></script>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
    integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
    <script src="https://d19vzq90twjlae.cloudfront.net/leaflet-0.7/leaflet.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js"></script>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Dashboard | iScout</title>

    @livewireStyles
</head>
<body>
<header>
    <div class="">

    </div>
</header>
<main class="flex ">
    <aside>
        <div class="w-60 shadow-md bg-white flex flex-col justify-between {{ request()->is('admin/settings') ? 'h-full' : 'h-screen' }}" id="sidenavSecExample">
            <div>
                <div class="pt-4 pb-2 px-6">
                    <a href="#!">
                    <div class="flex items-center">
                        <div class="shrink-0">
                        <img src="https://mdbcdn.b-cdn.net/img/new/avatars/8.webp" class="rounded-full w-10" alt="Avatar">
                        </div>
                        <div class="grow ml-3">
                        <p class="text-sm font-semibold text-blue-600">Hello, Admin!</p>
                        </div>
                    </div>
                    </a>
                </div>
                <ul class="relative px-1">
                    <li class="relative">
                    <a class="flex items-center text-sm py-4 px-6 h-12 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-blue-600 hover:bg-blue-50 transition duration-300 ease-in-out" href="{{ route('admin.dashboard') }}" data-mdb-ripple="true" data-mdb-ripple-color="primary">
                        <i data-lucide="home" class="w-4 h-4"></i>
                        <span class="pl-4">Dashboard</span>
                    </a>
                    </li>
                    <li class="relative" id="sidenavSecEx1">
                        <a class="flex items-center text-sm py-4 px-6 h-12 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-blue-600 hover:bg-blue-50 transition duration-300 ease-in-out cursor-pointer" data-mdb-ripple="true" data-mdb-ripple-color="primary" data-bs-toggle="collapse" data-bs-target="#collapseSidenavSecEx1" aria-expanded="false" aria-controls="collapseSidenavSecEx1">
                            <i data-lucide="user" class="w-4 h-4"></i>
                            <span class="pl-4">Driver</span>
                            <svg aria-hidden="true" focusable="false" data-prefix="fas" class="w-3 h-3 ml-auto" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                            <path fill="currentColor" d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path>
                            </svg>
                        </a>
                        <ul class="relative accordion-collapse collapse" id="collapseSidenavSecEx1" aria-labelledby="sidenavSecEx1" data-bs-parent="#sidenavSecExample">
                            <li class="relative">
                            <a href="{{ route('admin.driver') }}" class="flex items-center text-xs py-4 pl-12 pr-6 h-6 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-blue-600 hover:bg-blue-50 transition duration-300 ease-in-out" data-mdb-ripple="true" data-mdb-ripple-color="primary">Driver List</a>
                            </li>
                            <li class="relative">
                            <a href="{{ route('admin.time') }}" class="flex items-center text-xs py-4 pl-12 pr-6 h-6 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-blue-600 hover:bg-blue-50 transition duration-300 ease-in-out" data-mdb-ripple="true" data-mdb-ripple-color="primary">Time-in/out</a>
                            </li>
                        </ul>
                    </li>
                    <li class="relative" id="sidenavSecEx2">
                        <a class="flex items-center text-sm py-4 px-6 h-12 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-blue-600 hover:bg-blue-50 transition duration-300 ease-in-out cursor-pointer" data-mdb-ripple="true" data-mdb-ripple-color="primary" data-bs-toggle="collapse" data-bs-target="#collapseSidenavSecEx2" aria-expanded="false" aria-controls="collapseSidenavSecEx2">
                            <i data-lucide="car" class="w-4 h-4"></i>
                            <span class="pl-4">Vehicle</span>
                            <svg aria-hidden="true" focusable="false" data-prefix="fas" class="w-3 h-3 ml-auto" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                            <path fill="currentColor" d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path>
                            </svg>
                        </a>
                        <ul class="relative accordion-collapse collapse" id="collapseSidenavSecEx2" aria-labelledby="sidenavSecEx2" data-bs-parent="#sidenavSecExample">
                            <li class="relative">
                            <a href="{{ route('admin.vehicle') }}" class="flex items-center text-xs py-4 pl-12 pr-6 h-6 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-blue-600 hover:bg-blue-50 transition duration-300 ease-in-out" data-mdb-ripple="true" data-mdb-ripple-color="primary">Vehicle List</a>
                            </li>
                            <li class="relative">
                            <a href="{{ route('admin.drivervehicle') }}" class="flex items-center text-xs py-4 pl-12 pr-6 h-6 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-blue-600 hover:bg-blue-50 transition duration-300 ease-in-out" data-mdb-ripple="true" data-mdb-ripple-color="primary">Assign Drivers</a>
                            </li>
                        </ul>
                    </li>
                    <li class="relative">
                    <a class="flex items-center text-sm py-4 px-6 h-12 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-blue-600 hover:bg-blue-50 transition duration-300 ease-in-out" href="{{ route('admin.fuel') }}" data-mdb-ripple="true" data-mdb-ripple-color="primary">
                        <i class="mdi mdi-fuel" class="w-4 h-4"></i>
                        <span class="pl-4">Fuel</span>
                    </a>
                    </li>
                    <li class="relative">
                    <a class="flex items-center text-sm py-4 px-6 h-12 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-blue-600 hover:bg-blue-50 transition duration-300 ease-in-out" href="{{ route('admin.settings') }}" data-mdb-ripple="true" data-mdb-ripple-color="primary">
                        <i data-lucide="settings" class="w-4 h-4"></i>
                        <span class="pl-4">Settings</span>
                    </a>
                    </li>
                    <li class="relative">
                        <livewire:auth.logout/>
                    </li>
                </ul>
            </div>
            <div class="text-center bottom-0 w-full">
                <hr class="m-0">
                <p class="py-2 text-sm text-gray-700">iScout.com</p>
            </div>
        </div>
    </aside>
    <div class="w-full flex flex-col">
        <div class="shadow-md p-6">
            <span></span>
            <p class="font-bold">Dashboard</p>
        </div>
        <div class=" p-24 w-full">
            {{ $slot }}
        </div>
    </div>
</main>
@livewireScripts
<script src="https://unpkg.com/flowbite@1.4.5/dist/flowbite.js"></script>
<script src="/js/app.js"></script>
</body>
</html>